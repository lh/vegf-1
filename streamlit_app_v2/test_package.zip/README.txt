APE Simulation Package
=====================

Simulation ID: sim_20250607_130014_66ca99df
Package Version: 1.0
Created: 2025-06-07 13:08:27

This package contains a complete AMD Protocol Explorer simulation
including all patient data, protocol specifications, and audit logs.

To import this simulation:
1. Open APE application
2. Go to Protocol Manager
3. Use "Import Simulation Package" feature
4. Select this ZIP file

Package Contents:
- manifest.json: Package metadata and checksums
- data/: Patient data in Parquet format
- protocol.yaml: Protocol specification
- parameters.json: Simulation parameters
- audit_log.json: Complete audit trail

For support, please refer to APE documentation.
